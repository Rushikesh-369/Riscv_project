module cpu_tb;


reg clk;
reg reset;


cpu uut(

.clk(clk),
.reset(reset)

);



initial begin

clk=0;

forever #5 clk = ~clk;

end



initial begin


reset=1;

#20;

reset=0;


#200;


$finish;


end


initial begin

$monitor(
"time=%0t PC=%h",
$time,
uut.pc
);


end


endmodule