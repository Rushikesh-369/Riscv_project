module cpu(

input clk,
input reset

);


wire [31:0] pc;
wire [31:0] next_pc;


pc pc_unit(
.clk(clk),
.reset(reset),
.next_pc(next_pc),
.pc(pc)
);


// Instruction memory

reg [31:0] memory[0:255];

initial begin
    $readmemh("programs/test.mem",memory);
end


wire [31:0] instruction;

assign instruction = memory[pc>>2];



wire [6:0] opcode;
wire [4:0] rd;
wire [4:0] rs1;
wire [4:0] rs2;


assign opcode = instruction[6:0];
assign rd     = instruction[11:7];
assign rs1    = instruction[19:15];
assign rs2    = instruction[24:20];



wire reg_write;
wire mem_read;
wire mem_write;
wire branch;
wire alu_src;

wire [3:0] alu_control;



control control_unit(

.opcode(opcode),

.reg_write(reg_write),
.mem_read(mem_read),
.mem_write(mem_write),
.branch(branch),
.alu_src(alu_src),
.alu_control(alu_control)

);



wire [31:0] reg1;
wire [31:0] reg2;



wire [31:0] alu_b;



assign alu_b =
alu_src ?
{{20{instruction[31]}},instruction[31:20]} :
reg2;



wire [31:0] alu_result;
wire zero;



alu alu_unit(

.a(reg1),
.b(alu_b),
.alu_control(alu_control),

.result(alu_result),
.zero(zero)

);



register_file rf(

.clk(clk),

.reg_write(reg_write),

.rs1(rs1),
.rs2(rs2),

.rd(rd),

.write_data(alu_result),

.read_data1(reg1),
.read_data2(reg2)

);



assign next_pc =
(branch && zero) ?
pc + {{19{instruction[31]}},instruction[31:25],
instruction[11:7],1'b0} :
pc + 4;



endmodule