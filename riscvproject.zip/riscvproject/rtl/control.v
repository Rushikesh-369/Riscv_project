module control(

input [6:0] opcode,

output reg reg_write,
output reg mem_read,
output reg mem_write,
output reg branch,
output reg alu_src,
output reg [3:0] alu_control

);


always @(*)
begin

reg_write=0;
mem_read=0;
mem_write=0;
branch=0;
alu_src=0;
alu_control=4'b0000;


case(opcode)


7'b0110011: begin
// R type

reg_write=1;
alu_src=0;

end


7'b0010011: begin
// ADDI

reg_write=1;
alu_src=1;
alu_control=4'b0000;

end



7'b0000011: begin
// LW

reg_write=1;
mem_read=1;
alu_src=1;
alu_control=4'b0000;

end



7'b0100011: begin
// SW

mem_write=1;
alu_src=1;
alu_control=4'b0000;

end



7'b1100011: begin
// BEQ

branch=1;
alu_control=4'b0001;

end


endcase

end

endmodule